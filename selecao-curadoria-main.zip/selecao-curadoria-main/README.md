# Habilidades em Curadoria

A curadoria de dados constitui um conjunto de políticas e práticas voltadas para a seleção e gestão de dados, centradas no gerenciamento ativo e contínuo dos dados ao longo de seu ciclo de vida, visando sua relevância e utilidade. As atividades de curadoria facilitam a descoberta e recuperação de dados, bem como a compreensão desses dados, enquanto mantêm sua qualidade, permitindo sua reutilização ao longo do tempo.
Essa avaliação explorará algumas etapas da curadoria de dados, incluindo a recepção, avaliação, seleção, descrição e contextualização de dados. 

## Instruções

O material da selação está salvo no diretório deste projeto, bem como as orientações da tarefa. 
Todo material deverá ser salvo em sua pasta no GtHUB e/ou na pasta do Gdrive. O link para acesso da sua entrega deve ser cadastrado na plataforma Gupy.

